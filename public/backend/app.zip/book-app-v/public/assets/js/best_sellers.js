
$(document).ready(function(){
     
    printElementsGroup("best_sellers");
  
  });
  