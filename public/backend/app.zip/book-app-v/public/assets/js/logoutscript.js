var xhttp;


$(document).ready(function(){
    
    let returnFunction = function(){
        
        $("#text").text("Correctly Logout");
        
    };
    logoutFunc(returnFunction);
      
});